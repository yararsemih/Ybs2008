try:
    from tkinter import *
    from tkinter import ttk
    
except ImportError: 
    #for python 2.7+
    
    from Tkinter import *
    import ttk

#import subprocess
import subprocess
import sys





def isletmekar():
    try:
        subprocess.check_call([sys.executable, 'sub_programs/Odev1_isletmeKar.py'])
    except subprocess.CalledProcessError:
        subprocess.call(["python", "sub_programs/Odev1_isletmeKar.py"])
    
def OEE():
    try:
        subprocess.check_call([sys.executable, 'sub_programs/Odev2_OEE.py'])
    except subprocess.CalledProcessError:
        subprocess.call(["python", "sub_programs/Odev2_OEE.py"])
def ABC():
    try:
        subprocess.check_call([sys.executable, 'sub_programs/Odev3_AdambasiCiro.py'])
    except subprocess.CalledProcessError:
        subprocess.call(["python", "sub_programs/Odev3_AdambasiCiro.py"])

root = Tk()
root.title("isletme Takip Programi")

mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)
        
ttk.Button(mainframe, text="isletme Kari Hesapla", command=isletmekar).grid(column=2, row=2, sticky=W)
ttk.Button(mainframe, text="isletme OEE Hesapla", command=OEE).grid(column=2, row=3, sticky=W)
ttk.Button(mainframe, text="isletme Adam basi Ciro Hesapla", command=ABC).grid(column=2, row=4, sticky=W)

for child in mainframe.winfo_children():
            child.grid_configure(padx=5, pady=5)

#root.bind('<Return>', hesapla)
root.mainloop()
